<?php
/*
 * Template Name: Page d'accueil
 */
get_header();
?>

<div class="container">
    <div class="container__projects">
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
        <div class="project__item">
            <h4>DRE@M-X</h4>
            <span>Catégorie</span>
        </div>
    </div>

    

    <nav>
        <h5>Julia Garcin</h5>
        <h5>A propos</h5>    

        <div class="container__about">
            <div class="about__me">
                <a href="mailto:coucou@juliagarcin.com"><h5>coucou@juliagarcin.com</h5></a>         
                <p class="about__description">Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l'imprimerie depuis les années 1500, quand un imprimeur anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte.</p>
            </div>

            <div class="about__parutions">
                <h5>Articles QUD Magazine</h5>        
                <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
                <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
                <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
                <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
                <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
                <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
                <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
                <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
                <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>

            </div>

        </div>
    </nav>
</div>

<div class="container__images">
    <!-- swiper -->
    <!-- <div class="swiper&#45;container"> -->
    <!--     <div class="swiper&#45;wrapper"> -->
    <!--         <div class="swiper&#45;slide"> -->
    <!--             <img src="/wp&#45;content/uploads/2020/04/perimetre&#45;futures&#45;EP7&#45;1&#45;1.jpg" alt=""> -->
    <!--         </div> -->
    <!--         <div class="swiper&#45;slide"> -->
    <!--             <img src="/wp&#45;content/uploads/2020/04/w1.jpg" alt=""> -->
    <!--         </div> -->
    <!--     </div> -->
    <!-- </div> -->
    <img src="/wp-content/uploads/2020/04/perimetre-futures-EP7-1-1.jpg" alt="">

</div>


<?php get_footer(); ?>
