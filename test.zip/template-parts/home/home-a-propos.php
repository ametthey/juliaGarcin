<div class="container__about">
    <div class="about__me">
        <a href="mailto:coucou@juliagarcin.com"><h5>coucou@juliagarcin.com</h5></a>         
        <p class="about__description">Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l'imprimerie depuis les années 1500, quand un imprimeur anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte.</p>
    </div>

    <div class="about__parutions">
        <h5>Articles QUD Magazine</h5>        
        <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
        <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
        <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
        <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
        <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
        <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
        <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
        <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>
        <a href="https://www.lemonde.fr/" target="_blank">Le monde</a>

    </div>

</div>
