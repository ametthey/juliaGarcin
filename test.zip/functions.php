<?php

require_once( 'lib/helpers.php' );
require_once( 'lib/enqueue-assets.php' );

function after_pagination() {
	echo 'this is a text';
}

add_action( 'test_after_pagination' , 'after_pagination' )

?>
